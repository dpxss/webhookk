import discord
from discord.ext import commands
import os
# Set your Discord bot token here
TOKEN = 'MTE4NzA3OTg3MzQ0NjAxOTEzMg.GWBTmU.Xn5DWXZnhmTIYImfo0VtP2GtJtnDPUw0P8V704'

# Create an instance of the bot
bot = commands.Bot(command_prefix='!')

for root, dirs, files in os.walk("cogs"):
    for file in files:
        if file.endswith(".py"):
            cog_path = os.path.join(root, file)
            # Convert the path to dot notation
            module = cog_path.replace(os.sep, ".")[:-3]
            try:
                bot.load_extension(module)
                print(f"Loaded cog: {module}")
            except Exception as e:
                print(f"Failed to load cog: {module}\n{type(e).__name__}: {str(e)}")

# Event: Bot is ready
@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} ({bot.user.id})')
    print('------')


# Run the bot
bot.run(TOKEN)

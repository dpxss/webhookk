import time
import json
from discord.ext import commands
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from git import Repo
import requests
import time
import asyncio

class AutoCommitCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.repo_path = "/home/container"  # Set the path to your local Git repository
        self.branch_name = "main"  # Replace with your branch name
        self.webhook_url = "https://discord.com/api/webhooks/1187044013329616990/-uTBdEoBp4reJJtukcQt-XW3Bt02v1_VFw16Sqpq_mH5K2diUCU_W72nSfRWLHkMCzQn"  # Replace with your Discord webhook URL
        self.repo = Repo(self.repo_path)
        self.event_handler = MyHandler(self.repo, self.branch_name, self.webhook_url)

        # Initialize the observer but delay its start
        self.observer = Observer()
        self.observer.schedule(self.event_handler, path=self.repo_path, recursive=True)

        # Start the observer after a delay (adjust the delay as needed)
        self.bot.loop.create_task(self.delayed_start())

    async def delayed_start(self):
        await self.bot.wait_until_ready()
        await asyncio.sleep(5)  # Adjust the delay as needed
        self.observer.start()

    def cog_unload(self):
        # Stop the observer when the cog is unloaded
        self.observer.stop()
        self.observer.join()

class MyHandler(FileSystemEventHandler):
    def __init__(self, repo, branch_name, webhook_url):
        self.repo = repo
        self.branch_name = branch_name
        self.webhook_url = webhook_url
        
    def on_modified(self, event):
        if event.is_directory and ".git" in event.src_path:
            return

    # Check if the modification is related to the Git directory
        if event.src_path.endswith("/.git"):
            return

        if event.src_path.startswith(".git"):
            return

    # Check if the modification is a relevant code file (adjust the condition accordingly)
        if event.src_path.endswith((".py", ".txt")):
            modified_file = event.src_path
            commit_message = f"Automated commit: {modified_file}"

        # Commit changes
            self.repo.git.add(update=True)
            self.repo.index.commit(commit_message)

        # Push changes to GitHub
            origin = self.repo.remote(name="origin")
            origin.push(self.branch_name)

        # Trigger Discord notification via webhook
        # discord_payload = {"content": f"Bot updated and pushed to GitHub!\nModified file: {modified_file}"}
        # requests.post(self.webhook_url, data=json.dumps(discord_payload), headers={"Content-Type": "application/json"})


def setup(bot):
    bot.add_cog(AutoCommitCog(bot))
